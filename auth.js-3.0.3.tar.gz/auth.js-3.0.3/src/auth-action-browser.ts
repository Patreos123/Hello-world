export function createActionAuth() {
  throw new Error(
    "[@octokit/auth] `createActionAuth` is not supported in browsers"
  );
}
